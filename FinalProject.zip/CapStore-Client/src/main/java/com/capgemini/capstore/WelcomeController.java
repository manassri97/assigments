package com.capgemini.capstore;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstore.beans.ChangePasswordDummy;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Offer;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.User;

@Controller
public class WelcomeController {

	private Product tempProduct;
	
	@Autowired
	HttpServletRequest request;

	@Autowired
	HttpSession session;

	@Bean
	private RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Autowired
	RestTemplate restTemplate;

	@GetMapping
	public String getHome()
	{
		return "Home";
	}
	
	@GetMapping("/Admin")
	public String getAdminPage() {
		session = request.getSession(false);
		User user = new User();
		user = (User) session.getAttribute("user");
		session.setAttribute("user", user);

		if (session != null) {
			return "Admin";
		} else {
			return "Home";
		}
	}
	
	@GetMapping("/AllMerchants")
	public String getMerchantDetailsPage(ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		ArrayList<Merchant> list = restTemplate.getForObject("http://localhost:8088/showallmerchants", ArrayList.class);
		map.addAttribute("list", list);

		return "AllMerchants";
	}

	@GetMapping("/CheckOrdersByAdmin")
	public String getPendingOrder(ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		ArrayList<Order> list = restTemplate.getForObject("http://localhost:8088/CheckOrdersByAdmin", ArrayList.class);
		map.addAttribute("list", list);
		return "CheckOrdersByAdmin";
	}

	@GetMapping("/CheckOrdersByAdmin/{id}")
	public String getPendingOrder(@PathVariable String id, ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		int id1 = Integer.parseInt(id);
		ArrayList<Order> list = restTemplate.getForObject("http://localhost:8088/CheckOrdersByAdmin/" + id1,
				ArrayList.class);
		map.addAttribute("list", list);
		return "CheckOrdersByAdmin";
	}

	/*
	 * @RequestMapping(value = "/HomeCustomer", method = RequestMethod.POST,
	 * produces = "application/json") public String getSignUp(HttpServletRequest
	 * request) { User user = (User) session.getAttribute("user"); String name =
	 * restTemplate.postForObject("http://localhost:8088/getAdminName",user,
	 * String.class); map.addAttribute("Adminname", name); User user = new User();
	 * String email = request.getParameter("email"); user.setEmailId(email);
	 * user.setPassword(request.getParameter("password")); user.setRole("CUSTOMER");
	 * String str = restTemplate.postForObject("http://localhost:8088/logIn", user,
	 * String.class); return str; }
	 */
	///////////////////////////////////////////////////////////////////////////////////////////

	@GetMapping(value = "/ShowInventoryForAdminPage")
	public String showInventoryPage(ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		ArrayList<Product> list = restTemplate.getForObject("http://localhost:8088/viewProducts", ArrayList.class);
		map.addAttribute("list", list);
		return "ShowInventoryForAdmin";
	}

	@GetMapping(value = "/MerchantId")
	public String validateMerchantId(ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		return "MerchantId";
	}

	@GetMapping(value = "/AddProductsByAdmin")
	public String addProductByAdmin(HttpServletRequest request, ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		int id = Integer.parseInt(request.getParameter("merchant_id"));
		HttpSession session = request.getSession();
		session.setAttribute("merchantId", id);
		String str = restTemplate.getForObject("http://localhost:8088/verifyMerchant/" + id, String.class);
		return str;
	}

	@PostMapping(value = "/Admin")
	public String backToAdminFromAddSuccessfullProducts(HttpServletRequest request, ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		HttpSession session = request.getSession();
		int id = (int) session.getAttribute("merchantId");
		Product product = new Product();
		product.setProductBrand(request.getParameter("product_brand"));
		product.setProductCategory(request.getParameter("product_category"));
		product.setProductFeature("feature");
		product.setProductImageUrl("Image url");
		product.setProductModel(request.getParameter("product_model"));
		product.setProductName(request.getParameter("product_name"));
		product.setProductType(request.getParameter("product_type"));
		product.setProductPrice(Double.parseDouble(request.getParameter("product_price")));
		String str = restTemplate.postForObject("http://localhost:8088/addProduct/" + id, product, String.class);
		return str;
	}

	@GetMapping(value = "/DeleteProductsByAdmin")
	public String getDeleteProductsByAdminPage(ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		return "DeleteProductsByAdmin";
	}

	@GetMapping(value = "/ProductsList")
	public String validateMerchantAndGetProducts(HttpServletRequest request, ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		int id = Integer.parseInt(request.getParameter("merchantId"));
		HttpSession session = request.getSession();
		session.setAttribute("merchantId", id);
		ArrayList<Product> list = restTemplate.getForObject("http://localhost:8088/viewProductsByMerchant/" + id,
				ArrayList.class);
		map.addAttribute("list", list);
		return "ProductsListForAdmin";
	}

	@GetMapping(value = "/ProductsListForAdmin/{id}")
	public String removeProductByMerchant(@PathVariable String id, ModelMap map, HttpServletRequest request) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		HttpSession session = request.getSession();
		int merid = (int) session.getAttribute("merchantId");
		int id1 = Integer.parseInt(id);
		session.invalidate();
		String str = restTemplate.getForObject("http://localhost:8088/removeProduct/" + id1 + "/" + merid,
				String.class);
		System.out.println(str);
		return "DeleteProductsByAdmin";
	}

	@GetMapping(value = "/Pending")
	public String getDeleteMerchantPage(ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		ArrayList<Merchant> list = restTemplate.getForObject("http://localhost:8088/showallmerchants", ArrayList.class);
		map.addAttribute("list", list);
		return "Pending";
	}

	@GetMapping(value = "/rejectAMerchant/{id}")
	public String deleteMerchantByAdmin(@PathVariable String id, ModelMap map, HttpServletRequest request) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		int id1 = Integer.parseInt(id);
		String str = restTemplate.getForObject("http://localhost:8088/deleteMerchantByAdmin/" + id1, String.class);
		return str;
	}

	@GetMapping(value = "/UpdateProductByAdmin")
	public String getUpdateProductByAdminPage(ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		return "UpdateProductByAdmin";
	}

	@GetMapping(value = "/UpdateProductDetailsByAdmin")
	public String getUpdateProductDetailsByAdmin(ModelMap map) {
		User user = (User) session.getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getAdminName", user, String.class);
		map.addAttribute("Adminname", name);
		session = request.getSession();
		int merid = Integer.parseInt(request.getParameter("a1"));
		int proid = Integer.parseInt(request.getParameter("a2"));
		session.setAttribute("merid", merid);
		session.setAttribute("proid", proid);
		return "UpdateProductDetailsByAdmin";

	}

	/*
	 * @PostMapping(value = "/fileinsertmerchant") public String
	 * getUpdateProductPage(ModelMap map) { User user = (User)
	 * session.getAttribute("user"); String name =
	 * restTemplate.postForObject("http://localhost:8088/getAdminName", user,
	 * String.class); map.addAttribute("Adminname", name); session =
	 * request.getSession(); int merid = (int) session.getAttribute("merid"); int
	 * proid = (int) session.getAttribute("proid"); Product product = new Product();
	 * product.setProductName(request.getParameter("n1"));
	 * product.setProductBrand(request.getParameter("n2"));
	 * product.setProductCategory(request.getParameter("a3"));
	 * product.setProductType(request.getParameter("n3"));
	 * product.setProductModel(request.getParameter("n4"));
	 * product.setProductPrice(Integer.parseInt(request.getParameter("n5")));
	 * product.setProductImageUrl("kuch bhi"); product.setProductFeature("hatt");
	 * System.out.println("manas"); String str = restTemplate.postForObject(
	 * "http://localhost:8088/updateProductDetailByAdmin/"+merid+"/"+proid, product,
	 * String.class);
	 * 
	 * return "Admin"; }
	 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////Merchant/////////////////////////////////////////////////////////////////

	@RequestMapping(value = "/")
	public String getResponse(ModelMap map) 
	{
		session = request.getSession(false);
		User user = new User();
		user = (User) session.getAttribute("user");
		if (session != null) 
		{
			if(session.getAttribute("user")!=null)
			{
				System.out.println("a");
				if (user.getRole().equalsIgnoreCase("customer")) {
					return "Home";
				} else if (user.getRole().equalsIgnoreCase("merchant")) {
					return "MerchantHome";
				} else {
					return "Admin";
				}
			}
		}
		return "Home";

	}

	@RequestMapping("/MerchantHome")
	public String merchantHome(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (request.getSession(false) == null) {
			return "Home";
		}
		return "MerchantHome";
	}

	@RequestMapping("/AddProductsByMerchant")
	public String addProductsByMerchant(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (request.getSession(false) == null) {
			return "Home";
		}
		System.out.println("ihhv");
		return "AddProductsByMerchant";
	}

	@RequestMapping("/DeleteProductsByMerchant")
	public String deleteProductsByMerchant(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (request.getSession(false) == null) {
			return "Home";
		}
		return "DeleteProductsByMerchant";
	}

	@RequestMapping("/UpdateProductByMerchant")
	public String updateProductByMerchant(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (request.getSession(false) == null) {
			return "Home";
		}
		return "UpdateProductByMerchant";
	}

	@RequestMapping(value = "/findProductById", method = RequestMethod.POST, produces = "application/json")
	public String findProduct(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (request.getSession(false) == null) {
			return "Home";
		}
		String merchantEmail = ((User) request.getSession().getAttribute("user")).getEmailId();// "yanshu@gupta.com";
		String productId = request.getParameter("productId");
		tempProduct = restTemplate.postForObject("http://localhost:8088/getProduct/" + productId + "/" + merchantEmail, null,
				Product.class);
		return "UpdateProductDetailsByMerchant";
	}
	
	@RequestMapping("/ShowProductsForMerchant")
	public String showProductsForMerchant(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (session == null) {
			return "Home";
		}
		String merchantEmail = user.getEmailId();

		List<Product> list = restTemplate.postForObject("http://localhost:8088/getAllProducts/" + merchantEmail, null,List.class);
		map.addAttribute("list", list);
		return "ShowProductsForMerchant";
	}

	@RequestMapping(value = "/fileinsertmerchant", method = RequestMethod.POST)
	public String addProduct(ModelMap map) {
		System.out.println("b");
		User user = (User) request.getSession(false).getAttribute("user");
		System.out.println("a");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (session == null) {
			return "Home";
		}
		String merchantEmail = user.getEmailId();

		Product product = new Product();
		String productName = request.getParameter("productName");
//		String productImageUrl = request.getParameter("productImageUrl");
		String productCategory = request.getParameter("productCategory");
		String productBrand = request.getParameter("productBrand");
		String productModel = request.getParameter("productModel");
		String productType = request.getParameter("productType");
//		String productFeature = request.getParameter("productFeature");
		double productPrice = Double.parseDouble(request.getParameter("productPrice"));

		product.setProductBrand(productBrand);
		product.setProductCategory(productCategory);
		product.setProductFeature("feature");
		product.setProductImageUrl("Image url");
		product.setProductModel(productModel);
		product.setProductName(productName);
		product.setProductType(productType);
		product.setProductPrice(productPrice);
		System.out.println("manas");
		RestResponseAddProduct restRes = new RestResponseAddProduct();
		restRes.setProduct(product);

		String str = restTemplate.postForObject("http://localhost:8088/addProductByMerchant/" + merchantEmail, product, String.class);
		return str;
	}

	@RequestMapping(value = "/reduceproductbymerchant", method = RequestMethod.POST)
	public String deleteProduct(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (session == null) {
			return "Home";
		}
		String merchantEmail = user.getEmailId();
		String productId = request.getParameter("productId");
		String str = restTemplate.postForObject("http://localhost:8088/removeProductByMerchant/" + productId + "/" + merchantEmail, null,
				String.class);
		if (str.equals("success")) {
			return "DeleteProductsByMerchant";
		} else {
			return "DeleteProductsByMerchant";
		}
	}

	@RequestMapping(value = "/fileupdatemerchant", method = RequestMethod.POST, produces = "application/json")
	public String updateMerchantProduct(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (session == null) {
			return "Home";
		}
		String merchantEmail = user.getEmailId();
		Product product = new Product();
		String productName = request.getParameter("productName");
//		String productImageUrl = request.getParameter("productImageUrl");
		String productCategory = request.getParameter("productCategory");
		String productBrand = request.getParameter("productBrand");
		String productModel = request.getParameter("productModel");
		String productType = request.getParameter("productType");
//		String productFeature = request.getParameter("productFeature");
		double productPrice = Double.parseDouble(request.getParameter("productPrice"));

		product.setProductBrand(productBrand);
		product.setProductCategory(productCategory);
		product.setProductFeature("feature");
		product.setProductImageUrl("Image url");
		product.setProductModel(productModel);
		product.setProductName(productName);
		product.setProductType(productType);
		product.setProductPrice(productPrice);
		product.setProductId(tempProduct.getProductId());

		System.out.println(product);

		RestResponseAddProduct restRes = new RestResponseAddProduct();
		restRes.setProduct(product);

		String str = restTemplate.postForObject("http://localhost:8088/updateProduct/" + merchantEmail, product, String.class);
		// msg -> Product updated success
		return str;
	}

	@RequestMapping(value = "/Login")
	public String getSignUp() {
		
		if (session == null) {
			return "Login";
		}
		return "Login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json")
	public String enterSignUpDetails() {
		User user = new User();
		String email = request.getParameter("email");
		user.setEmailId(email);
		String password = request.getParameter("password");
		user.setPassword(password);
		String role = request.getParameter("a3");
		System.out.println(user.getEmailId() + user.getPassword());
		user.setRole(role);
		System.out.println(user.getRole());
		session = request.getSession(true);
		session.setMaxInactiveInterval(0);
		session.setAttribute("user", user);
		String str = restTemplate.postForObject("http://localhost:8088/logIn", user, String.class);
		return str;
	}

	@RequestMapping(value = "/Ask")
	public String getSignUpDetails() {

		return "Ask";
	}

	@RequestMapping(value = "/ForgotPassword")
	public String forgotPassword() {

		return "ForgotPassword";
	}

	@RequestMapping(value = "/ForgotPasswordd", method = RequestMethod.POST, produces = "application/json")
	public String afterForgotPassword() {

		User user = new User();
		String email = request.getParameter("n4");
		String securityQuestion = request.getParameter("a4");
		String securityAnswer = request.getParameter("n2");
		user.setEmailId(email);
		user.setSecurityAnswer(securityAnswer);
		user.setSecurityQuestion(securityQuestion);
		HttpSession session = request.getSession(true);
		session.setAttribute("user", user);
		String str = restTemplate.postForObject("http://localhost:8088/forgotPassword", user, String.class);
		return str;

	}

	@RequestMapping(value = "/Home", method = RequestMethod.POST, produces = "application/json")
	public String successfullChagePassword() {

		String password = request.getParameter("n3");
		String confirmPassword = request.getParameter("n4");
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		user.setPassword(password);

		if (password.equals(confirmPassword)) {

			String str = restTemplate.postForObject("http://localhost:8088/passwordChangePage", user, String.class);
			return str;

		}

		return "ForgotPasswordConfirmation";
	}

	@RequestMapping(value = "/SignUp", method = RequestMethod.POST, produces = "application/json")
	public String validateSignUpDetails() {

		User user = new User();
		String email = request.getParameter("a1");
		user.setEmailId(email);
		String password = request.getParameter("a2");
		user.setPassword(password);
		String role = request.getParameter("a3");
		user.setRole(role);
		String securityQuestion = request.getParameter("a4");
		user.setSecurityQuestion(securityQuestion);
		String securityAnswer = request.getParameter("a5");
		user.setSecurityAnswer(securityAnswer);
		String str = restTemplate.postForObject("http://localhost:8088/signUp", user, String.class);
		if (str.equals("ask")) {
			// set msg
		}
		return str;
	}

	@RequestMapping(value = "/Customer_OTP", method = RequestMethod.POST, produces = "application/json")
	public String enterMoreSignUpDetailsCustomer() {

		Customer customer = new Customer();
		String name = request.getParameter("n2");
		String email = request.getParameter("n5");
		String mobileNo = request.getParameter("n4");
		String address = request.getParameter("n8");
		String pincode = request.getParameter("n6");
		customer.setCustomerAddress(address);
		customer.setCustomerEmail(email);
		customer.setCustomerMobileNumber(mobileNo);
		customer.setCustomerName(name);
		customer.setCustomerPincode(pincode);
		String str = restTemplate.postForObject("http://localhost:8088/registerCustomer", customer, String.class);
		return str;

	}

	@RequestMapping(value = "/Merchant_OTP", method = RequestMethod.POST, produces = "application/json")
	public String enterMoreSignUpDetailsMerchant() {

		Merchant merchant = new Merchant();
		String name = request.getParameter("n1");
		String email = request.getParameter("n2");
		String storeName = request.getParameter("n3");
		String mobileNo = request.getParameter("n4");
		String address = request.getParameter("n5");
		merchant.setMerchantAddress(address);
		merchant.setMerchantEmail(email);
		merchant.setMerchantMobileNumber(mobileNo);
		merchant.setMerchantName(name);
		merchant.setMerchantStoreName(storeName);
		String str = restTemplate.postForObject("http://localhost:8088/registerMerchant", merchant, String.class);
		return str;
	}

	@RequestMapping(value = "/ChangePassword")
	public String getChangePasswordPage() {
		return "ChangePassword";
	}

	@RequestMapping("/logOut")
	public String logOut() {
		session.invalidate();
		return "Home";

	}

	@RequestMapping(value = "/changePassword", method = RequestMethod.POST)
	public String changePasword() {

		String str = null;
		String currentPassword = request.getParameter("n2");
		String newPassword = request.getParameter("n3");
		String confirmNewPassword = request.getParameter("n4");
		ChangePasswordDummy dummy = new ChangePasswordDummy();
		HttpSession session = request.getSession(true);
		User user = (User) session.getAttribute("user");
		System.out.println(user);
		dummy.setEmail(user.getEmailId());
		dummy.setOldPassword(currentPassword);
		dummy.setNewPassword(newPassword);
		dummy.setRole(user.getRole());
		System.out.println("hii");
		if (newPassword.equals(confirmNewPassword)) {
			str = restTemplate.postForObject("http://localhost:8088/changePasswordd", dummy, String.class);
		}
		return str;
	}
	@RequestMapping("/CheckOrdersByMerchant")
	public String checkOrdersByMerchant(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (session == null) {
			return "Home";
		}
		String merchantEmail = user.getEmailId();
		List<Order> orderList = restTemplate.postForObject("http://localhost:8088/findOrdersByMerchant/"+merchantEmail, null, List.class);
		map.addAttribute("list", orderList);
		return "CheckOrdersByMerchant";
	}
	@RequestMapping("/DiscountByMerchant")
	public String discountByMerchant(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (session == null) {
			return "Home";
		}
		
		return "DiscountByMerchant";
	}
	@RequestMapping("/addDiscount")
	public String addDiscount(ModelMap map) {
		User user = (User) request.getSession(false).getAttribute("user");
		String name = restTemplate.postForObject("http://localhost:8088/getMerchantName", user, String.class);
		map.addAttribute("Merchantname", name);
		if (session == null) {
			return "Home";
		}
		Offer offer = new Offer();
		String merchantEmail = ((User) request.getSession().getAttribute("user")).getEmailId();// "yanshu@gupta.com";
		String productId = request.getParameter("productId");
		tempProduct = restTemplate.postForObject("http://localhost:8088/getProduct/" + productId + "/" + merchantEmail, null,
				Product.class);
		offer.setProduct(tempProduct);
		
		Merchant merchant = restTemplate.postForObject("http://localhost:8088/getMerchant/" + merchantEmail, null,
				Merchant.class);
		offer.setMerchant(merchant);
		
		restTemplate.postForObject("http://localhost:8088/changePasswordd", offer, Void.class);
		return "DiscountByMerchant";
	}
	
	
}