package com.capgemini.capstore.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Order;
@Repository
@Transactional
public interface ICapStoreOrderDAO extends JpaRepository<Order, Integer> {

public List<Order> findByDeliveryStatusNotIn(String a);
	
	@Modifying
	@Query(value="update orderdetail o set o.deliverystatus =:status where o.orid =:id",nativeQuery=true)
	public int setStatus(@Param("status") String status,@Param("id") int id);

	List<Order> findByMerchant(Merchant merchant);
}
