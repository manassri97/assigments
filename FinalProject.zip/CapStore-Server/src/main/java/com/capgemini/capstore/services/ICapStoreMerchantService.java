package com.capgemini.capstore.services;

import java.util.List;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;

public interface ICapStoreMerchantService {

	void registerMerchant(Merchant merchant);

	void registerCustomer(Customer customer);
	
	Product addProduct(Product product, String merchantEmail);

	Product updateProduct(Product product, String merchantEmail);

	Product getProduct(int productId, String merchantEmail);

	boolean removeProduct(int productId, String merchantEmail);

	List<Product> getAllProducts(String merchantEmail);

	List<Order> findOrdersByMerchant(String merchantEmail);

	public String getMerchantName(String merchantEmail);

}
