package com.capgemini.capstore.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.User;
import com.capgemini.capstore.services.ICapStoreMerchantService;

@RestController
public class CapStoreMerchantController {

	@Autowired
	ICapStoreMerchantService service;

	@PostMapping(value="/getMerchantName")
	public String getMerchantName(@RequestBody User user)
	{
		System.out.println(user.getEmailId());
		return service.getMerchantName(user.getEmailId());
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/getProduct/{productId}/{merchantEmail}")
	public Product getProduct(@PathVariable int productId, @PathVariable String merchantEmail,
			HttpServletRequest request) {

		return service.getProduct(productId, merchantEmail);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/getAllProducts/{merchantEmail}")
	public List<Product> getAllProducts(@PathVariable String merchantEmail, HttpServletRequest request) {

		return service.getAllProducts(merchantEmail);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/addProductByMerchant/{merchantEmail}")
	public String addProduct(@RequestBody Product product, @PathVariable String merchantEmail) {

		service.addProduct(product, merchantEmail);
		return "MerchantHome";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/updateProduct/{merchantEmail}")
	public String updateProduct(@RequestBody Product product, @PathVariable String merchantEmail) {

		service.updateProduct(product, merchantEmail);
		return "MerchantHome";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/removeProductByMerchant/{productId}/{merchantEmail}")
	public String removeProduct(@PathVariable int productId, @PathVariable String merchantEmail) {

		service.removeProduct(productId, merchantEmail);
		return "success";

	}

	@RequestMapping(method = RequestMethod.POST, value = "/findOrdersByMerchant/{merchantEmail}")
	public List<Order> findOrdersByMerchant(@PathVariable String merchantEmail) {

		return service.findOrdersByMerchant(merchantEmail);

	}
}
