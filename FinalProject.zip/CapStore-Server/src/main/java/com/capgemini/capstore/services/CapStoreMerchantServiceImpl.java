package com.capgemini.capstore.services;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.dao.ICapStoreCustomerDAO;
import com.capgemini.capstore.dao.ICapStoreMerchantDAO;
import com.capgemini.capstore.dao.ICapStoreOrderDAO;
import com.capgemini.capstore.dao.ICapStoreProductDAO;

@Service
public class CapStoreMerchantServiceImpl implements ICapStoreMerchantService {

	@Autowired
	ICapStoreMerchantDAO merchantRepo;
	
	@Autowired
	ICapStoreCustomerDAO customerRepo;
	
	@Autowired
	ICapStoreProductDAO productRepo;
	
	@Autowired
	ICapStoreOrderDAO orderRepo;
	
	@Override
	public void registerMerchant(Merchant merchant) {
		
		merchantRepo.save(merchant);
	}

	@Override
	public void registerCustomer(Customer customer) {
		customerRepo.save(customer);
		
	}

	@Override
	public Product getProduct(int productId, String merchantEmail) {

		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail+".com");
		for (Product product : merchant.getProducts()) {
			if (product.getProductId() == productId) {
				return product;
			}
		}
		return null;
	}
	
	@Override
	public List<Product> getAllProducts(String merchantEmail) {
		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail+".com");
		return merchant.getProducts();
	}

	@Override
	public Product addProduct(Product product, String merchantEmail) {
		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail+".com");
		List<Product> productList = merchant.getProducts();
		System.out.println(productList);
		productList.add(product);
		System.out.println("a");
		merchantRepo.save(merchant);
		return product;
	}

	@Override
	public Product updateProduct(Product product, String merchantEmail) {
		System.out.println(merchantEmail);
		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail+".com");
		for (Product productObj : merchant.getProducts()) {
			if (product.getProductId() == productObj.getProductId()) {
				productRepo.save(product);
				merchantRepo.save(merchant);
				return product;
			}
		}
		return null;
	}

	@Override
	public boolean removeProduct(int productId, String merchantEmail) {

		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail+".com");
		Iterator<Product> itr = merchant.getProducts().iterator();
		while (itr.hasNext()) {
			Product product = itr.next();
			if (product.getProductId() == productId) {
				itr.remove();
				productRepo.deleteById(productId);
				merchantRepo.save(merchant);
				return true;
			}
		}
		return false;
	}

	@Override
	public List<Order> findOrdersByMerchant(String merchantEmail) {
		
		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);
		List<Order> orderList = orderRepo.findByMerchant(merchant);
		return orderList;
	}

	@Override
	public String getMerchantName(String merchantEmail) {
		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);
		return merchant.getMerchantName(); 
	}
}
