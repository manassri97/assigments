package com.capgemini.capstore.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.ChangePasswordDummy;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.User;
import com.capgemini.capstore.services.ICapStoreAdminService;
import com.capgemini.capstore.services.ICapStoreCommonService;
import com.capgemini.capstore.services.ICapStoreCustomerService;
import com.capgemini.capstore.services.ICapStoreMerchantService;

@RestController
public class URIController {
	
	@Autowired
	ICapStoreCommonService commonService;

	@Autowired
	ICapStoreAdminService adminService;

	@Autowired
	ICapStoreMerchantService merchantService;

	@Autowired
	ICapStoreCustomerService customerService;

	@RequestMapping(value = "/logIn", method = RequestMethod.POST)
	public String logIn(@RequestBody User user, HttpServletRequest request) {
		
		boolean result = false;
		try {
			
			result = commonService.ValidateLogIn(user);
			if(result) {
							
				if (user.getRole().equals("ADMIN")) {
					
					return "Admin";
					
				}
				if (user.getRole().equals("MERCHANT")) {
									
					return "MerchantHome";				
									
				}
				if (user.getRole().equals("CUSTOMER")) {
					
					return "HomeCustomer";
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Home";
	}

	@RequestMapping(value = "/logOut", method = RequestMethod.GET)
	public String logOut(HttpServletRequest request) {
		
		return "indexPage";
		
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
	public String forgotPassword(@RequestBody User user, HttpServletRequest request) {
		
		User result = null;
		
		if ((result = commonService.isValidEmail(user.getEmailId())) != null) {
			
			if(user.getSecurityQuestion().equals(result.getSecurityQuestion()) && user.getSecurityAnswer().equals(result.getSecurityAnswer())) {
				
				return "ForgotPasswordConfirmation";
				
			}
			
		}
		
		return "ForgotPassword";
	}

	@RequestMapping(value = "/passwordChangePage", method = RequestMethod.POST)
	public String passwordChangePage(@RequestBody User user, HttpServletRequest request) {
		
		commonService.updatePassword(user.getEmailId(), user.getPassword());
		return "Home";
		
	}

	@RequestMapping(value = "/changePasswordd", method = RequestMethod.POST)
	public String changePassword(@RequestBody ChangePasswordDummy changePassword,	HttpServletRequest request) {
		
		if (commonService.changePassword(changePassword.getEmail(),changePassword.getOldPassword(),changePassword.getNewPassword())) {
			if(changePassword.getRole().equals("CUSTOMER"))
				return "HomeCustomer";
			if(changePassword.getRole().equals("MERCHANT"))
				return "MerchantHome";
			if(changePassword.getRole().equals("ADMIN"))
				return "Admin";
		}
		
		return "changePassword";
	}

	@RequestMapping(value = "/signUp", method = RequestMethod.POST)
	public String signUp(@Valid @RequestBody User user) {
	
		if (commonService.ValidateUserDetails(user)) {
			if(user.getRole().equalsIgnoreCase("CUSTOMER"))
				return "CustomerSignUp";
			if(user.getRole().equalsIgnoreCase("MERCHANT"))
				return "MerchantSignUp";
		}
			return "ask";
	}
	
	@RequestMapping(value = "/registerMerchant", method = RequestMethod.POST)
	public String finalRegistrationForMerchant(@RequestBody Merchant merchant) {
		merchant.setMerchantRating(1);
		merchant.setProducts(new ArrayList<Product>());
		merchantService.registerMerchant(merchant);
		
		return "Login";
		
	}

	@RequestMapping(value = "/registerCustomer", method = RequestMethod.POST)
	public String finalRegistrationForCustomer(@RequestBody Customer customer) {
		merchantService.registerCustomer(customer);
		return "Login";
		
	}
}
