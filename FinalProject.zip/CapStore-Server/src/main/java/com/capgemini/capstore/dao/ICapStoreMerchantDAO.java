package com.capgemini.capstore.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Merchant;
@Repository
@Transactional
public interface ICapStoreMerchantDAO extends JpaRepository<Merchant, Integer> {

	public static final String Find_Merchant = "SELECT merchantid, merchantName, Email, MobileNo, Address,StoreName, merchantrating FROM Merchantdetail";

	@Query(value = Find_Merchant, nativeQuery = true)
	public List<Merchant> findMerchant();

	public Merchant findByMerchantId(int id);
	
	public Merchant findByMerchantEmail(String merchantEmail);
	
	@Modifying
	@Transactional
	public int deleteByMerchantId(int id);
	
}
