package com.capgemini.capstore.controllers;

import com.capgemini.capstore.beans.User;

public class RestResponseUser {
	

	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public RestResponseUser() {
		super();
	}
	
	
	

}
