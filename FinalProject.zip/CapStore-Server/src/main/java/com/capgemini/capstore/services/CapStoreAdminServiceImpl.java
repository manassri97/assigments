package com.capgemini.capstore.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.dao.ICapStoreAdminDAO;
import com.capgemini.capstore.dao.ICapStoreMerchantDAO;
import com.capgemini.capstore.dao.ICapStoreOrderDAO;
import com.capgemini.capstore.dao.ICapStoreProductDAO;
import com.capgemini.capstore.dao.ICapStoreUserDAO;
import com.capgemini.capstore.exceptions.InvalidProductIdException;
@Transactional
@Service
public class CapStoreAdminServiceImpl implements ICapStoreAdminService {

	@Autowired
	ICapStoreUserDAO capstoreUser;
	
	@Autowired
	ICapStoreAdminDAO capstoreAdmin;
	
	@Autowired
	ICapStoreOrderDAO capstoreOrder;
	
	@Autowired
	ICapStoreMerchantDAO capstoreMerchant;
	
	@Autowired
	ICapStoreProductDAO capstoreProduct;
	
	@Override
	public List<Order> getAllPendingOrders() {
		return capstoreOrder.findByDeliveryStatusNotIn("DELIVERED");
	}

	@Override
	public List<Merchant> getAllMerchant() {
		List<Merchant> list = capstoreMerchant.findMerchant();
		return capstoreMerchant.findMerchant();
	}

	@Override
	public List<Order> changeOrderStatus(int id) {
		capstoreOrder.setStatus("DELIVERED", id);
		return capstoreOrder.findByDeliveryStatusNotIn("DELIVERED");
	}
	///////////////////////////////////////////////////
	public List<Product> getProductList() {
		return capstoreProduct.findAll();
	}

	public void addProducts(int id, Product product) {
		if(capstoreMerchant.existsById(id))
		{
			Merchant merchant = capstoreMerchant.findByMerchantId(id);
			System.out.println(merchant);
			List<Product> list = new ArrayList<>();
			list.add(product);
			merchant.setProducts(list);
			capstoreProduct.save(product);
			capstoreMerchant.save(merchant);
		}
		
	}

	public Product updateProducts(int merid, int proid,Product product) {
		Merchant merchant = capstoreMerchant.findByMerchantId(merid);
		Product prod = capstoreProduct.findById(proid).get();
		List<Product> list = merchant.getProducts();
		list.remove(prod);
		list.add(product);
		capstoreProduct.delete(prod);
		capstoreMerchant.save(merchant);
		return product;
	}

	public boolean deleteProducts(int id, int merid) {
		Merchant merchant = capstoreMerchant.findByMerchantId(merid);
		List<Product> list = merchant.getProducts();
		list.remove(capstoreProduct.findByProductId(id));
		capstoreMerchant.save(merchant);
		capstoreProduct.delete(capstoreProduct.findByProductId(id));
		return true;
	}

	public Product getProductDetails(int product_id) throws InvalidProductIdException {
		if (capstoreProduct.findById(product_id) == null) {                                 //checking product id exist or not
			throw new InvalidProductIdException("The Product ID you entered is wrong and it does not exists");
		}
		
		return capstoreProduct.findById(product_id).get();
	}

	@Override
	public boolean verifyMerchant(int id) {
		if(capstoreMerchant.existsById(id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public List<Product> getProductsByMerchant(int id) {
		Merchant merchant = capstoreMerchant.findByMerchantId(id);
		return merchant.getProducts();
	}
	
	@Override
	public boolean deleteMerchantByAdmin(int id) {
		Merchant merchant = capstoreMerchant.findByMerchantId(id);
		System.out.println(merchant.getMerchantEmail());
		if(capstoreMerchant.deleteByMerchantId(id)>0)
		{
			capstoreUser.deleteByEmailId(merchant.getMerchantEmail());
			return true;
		}
		return false;
	}

	@Override
	public String getAdminName(String email) {
		Admin admin = capstoreAdmin.findByAdminEmail(email);
		return admin.getAdminName(); 
	}
}
