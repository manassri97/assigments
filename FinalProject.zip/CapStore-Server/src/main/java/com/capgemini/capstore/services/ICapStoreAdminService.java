package com.capgemini.capstore.services;

import java.util.List;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.exceptions.InvalidProductIdException;

public interface ICapStoreAdminService {
	
	public List<Order> getAllPendingOrders();

	public List<Merchant> getAllMerchant();

	public List<Order> changeOrderStatus(int id);
	
	public List<Product> getProductList();
	
	public void addProducts(int id, Product product);
	
	public Product updateProducts(int merid, int product_id, Product product);
	
	public boolean deleteProducts(int product_id, int merid) ;
	
	public Product getProductDetails(int product_id) throws InvalidProductIdException;

	public boolean verifyMerchant(int id);

	public List<Product> getProductsByMerchant(int id);

	public boolean deleteMerchantByAdmin(int id);

	public String getAdminName(String email);
}
