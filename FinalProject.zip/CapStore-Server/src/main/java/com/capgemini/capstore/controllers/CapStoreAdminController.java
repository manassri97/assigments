package com.capgemini.capstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.User;
import com.capgemini.capstore.exceptions.InvalidProductIdException;
import com.capgemini.capstore.services.ICapStoreAdminService;

@RestController
public class CapStoreAdminController {

	@Autowired
	ICapStoreAdminService capstoreService;
	
	@PostMapping(value="/getAdminName")
	public String getAdminName(@RequestBody User user)
	{
		return capstoreService.getAdminName(user.getEmailId());
	}
	
	@RequestMapping(value="/CheckOrdersByAdmin",method=RequestMethod.GET)
	public List<Order> showAllPendingOrder()
	{
		return capstoreService.getAllPendingOrders();
	}
	
	@RequestMapping(value="/showallmerchants",method=RequestMethod.GET)
	public List<Merchant> showAllMerchant()
	{
		return capstoreService.getAllMerchant();
	}
	
	@RequestMapping(value="/CheckOrdersByAdmin/{id}",method=RequestMethod.GET)
	public List<Order> changeStatus(@PathVariable int id)
	{
		return capstoreService.changeOrderStatus(id);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////
	
	@RequestMapping(method = RequestMethod.GET, value = "/viewProducts")
	public List<Product> getProductList() {
		return (List<Product>) capstoreService.getProductList();
	}

	@GetMapping(value="/verifyMerchant/{id}")
	public String verifyMerchant(@PathVariable int id)
	{
		if(capstoreService.verifyMerchant(id))
		{
			return "AddProductsByAdmin";
		}
		else
		{
			return "Admin";
		}
	}
	
	@GetMapping(value="/validateMerchant/{id}")
	public String validMerchants(@PathVariable int id)
	{
		if(capstoreService.verifyMerchant(id))
		{
			return "null";
		}
		else
		{
			return "Admin";
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/addProduct/{id}")
	public String addProducts(@RequestBody Product products,@PathVariable int id) {
		capstoreService.addProducts(id,products);
		return "Admin";
	}
	
	@GetMapping(value="/viewProductsByMerchant/{id}")
	public List<Product> getProductsByMerchant(@PathVariable int id)
	{
		return capstoreService.getProductsByMerchant(id);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/removeProduct/{id}/{merid}")
	public String deleteProduct(@PathVariable int id, @PathVariable int merid) {

		if(capstoreService.deleteProducts(id,merid))
		{
			return "DeleteProductsByAdmin";
		}
		else
		{
			return "Admin";
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = "/productDetail/{product_id}")
	public Product getProductDetails(@PathVariable int product_id) throws InvalidProductIdException {
		return capstoreService.getProductDetails(product_id);
	}
	 
	 @GetMapping(value="/deleteMerchantByAdmin/{id}")
	 public String deleteMerchantByAdmin(@PathVariable int id)
	 {
		 if(capstoreService.deleteMerchantByAdmin(id))
		 {
			 return "Pending";
		 }
		 else
			 return "Admin";
	 }
	 
	 @PostMapping(value="/updateProductDetailByAdmin/{merid}/{proid}")
	 public String updateProductDetailByAdmin(@PathVariable int merid,@PathVariable int proid,@RequestBody Product product)
	 {
		 capstoreService.updateProducts(merid, proid,product);
		 System.out.println("b");
		 return "Admin"; 
	 }
}
